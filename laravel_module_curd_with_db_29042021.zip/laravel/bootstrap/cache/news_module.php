<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\News\\Providers\\NewsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\News\\Providers\\NewsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
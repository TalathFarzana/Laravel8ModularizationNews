<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BlogCategory\\Providers\\BlogCategoryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BlogCategory\\Providers\\BlogCategoryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
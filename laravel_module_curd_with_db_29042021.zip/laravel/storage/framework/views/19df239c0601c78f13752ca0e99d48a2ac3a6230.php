<p>Dashboard Site Status Model from views\index page not Models.</p>

<?php

//return view('dashboard::sites.index');


?><?php /**PATH C:\xampp\htdocs\signup\Dashboard/views/sites/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <h1>Hello Laravel</h1>

    <p>
        This view is loaded from module: <?php echo config('blog.name'); ?>

        <br>Laravel 5.4 Modulation completed.
        <br>Need to work on Laravel 8 Modulation.
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('blog::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\signup\Modules/Blog\Resources/views/index.blade.php ENDPATH**/ ?>
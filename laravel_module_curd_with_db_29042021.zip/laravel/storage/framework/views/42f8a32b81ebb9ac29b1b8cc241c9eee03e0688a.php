<p>Create ToDo View Page</p>

<?php

//return view('todo::create_todo');


?><?php /**PATH C:\xampp\htdocs\signup\Todo/views/create_todo.blade.php ENDPATH**/ ?>
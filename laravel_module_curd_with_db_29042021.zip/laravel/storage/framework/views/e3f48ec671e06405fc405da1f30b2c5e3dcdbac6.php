<?php $__env->startSection('content'); ?>
   <!-- <h1>Hello World</h1>

    <p>
        This view is loaded from module: <?php echo config('news.name'); ?>

    </p>-->

    <h1 style="text-align:center;"> Add News</h1>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('update_success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('update_success')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('delete_success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('delete_success')); ?>

    </div>
    <?php endif; ?>
    <form action="<?php echo e(url('news/create')); ?>" method="post" name="news_form" id="news_form">
    <?php echo csrf_field(); ?>
    <div class="form-group" style="text-align:center;">     
        <input type="text" name="title" class="<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="submit" value="Add" name="add">
    </div>     
   </form>
   
   <div class="form-group" style="text-align:center;">
   <button class="btn btn-primary"><a href="/news"  style="text-align:center;text-decoration:none;color:#ffffff;">Back</a></button>
   </div> 

   <div class="form-group" style="margin-left:350px;margin-top:25px;">
   <h2>News Titiles List:</h2>
   <?php if(!empty($news_titles_list) && $news_titles_list->count()): ?>
   <?php $__currentLoopData = $news_titles_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($news_list['id']); ?>. <?php echo e($news_list['title']); ?></br>
        <span style="margin-left:10px;"><a href="news/<?php echo e($news_list['id']); ?>"><input type="submit" class="btn btn-primary" value="Edit"></a></span>
        <span style="margin-left:25px;"><a href="/news/delete/<?php echo e($news_list['id']); ?>"><input type="submit" class="btn btn-danger" value="Delete"></a></span></br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <span style="margin-left:25px;">There are no data.</span>
    <?php endif; ?>
    </div> 
    <div class="form-group" style="margin-left:350px;margin-top:25px;">
    <?php echo $news_titles_list->links(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('news::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\signup\Modules/News\Resources/views/index.blade.php ENDPATH**/ ?>
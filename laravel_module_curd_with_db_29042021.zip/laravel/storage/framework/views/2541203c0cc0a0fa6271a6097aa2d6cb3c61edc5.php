<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News | Create</title>
</head>
<body style="text-align:center;">
    <h1>Add News</h1>
    <form action="/store" method="POST">
    <?php echo csrf_field(); ?>
        <input type="text" name="title">
        <input type="submit" value="Add" name="add">
    </form>
    <a href="/news">Back</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\signup\Modules/News\Resources/views/create.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>News | Edit</title>
</head>
<body>
<h1 style="text-align:center;">Edit News</h1>

    <form action="<?php echo e(url('news/update')); ?>" method="POST" name="news_edit_form" id="news_edit_form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <div class="form-group" style="text-align:center;">
    <input type="hidden" name="id" value="<?php echo e($edit_news['id']); ?>" readonly="readonly">
    <input type="text" name="title" value="<?php echo e($edit_news['title']); ?>" class="<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>        
    <input type="submit" value="Update" name="update" class="btn btn-primary">
    </div>        
   </form>
   
   <div class="form-group" style="text-align:center;">
   <button class="btn btn-primary"><a href="/news"  style="text-align:center;text-decoration:none;color:#ffffff;">Back</a></button>
   </div> 
</body>
</html><?php /**PATH C:\xampp\htdocs\signup\Modules/News\Resources/views/edit.blade.php ENDPATH**/ ?>
<?php
use Illuminate\Support\Facades\Route;
use Modules\News\Http\Controllers\NewsController;

Route::get('/', [NewsController::class, 'index']);
Route::post('/create', [NewsController::class, 'store']);
Route::get('/{id}', [NewsController::class, 'edit']);
//Route::get('/edit/{id}', [NewsController::class, 'edit']);
Route::patch('/update', [NewsController::class, 'update']);
Route::get('/delete/{id}', [NewsController::class, 'destroy']);
?>
-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2021 at 11:00 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2021_04_28_071720_create_news_models_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news_models`
--

CREATE TABLE `news_models` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news_models`
--

INSERT INTO `news_models` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'First News', NULL, '2021-04-29 00:39:46'),
(2, 'sPE1WAYxK1', NULL, NULL),
(3, 'updating DB seeder title', NULL, '2021-04-29 00:39:33'),
(4, 'first news xyd', '2021-04-28 06:45:41', '2021-04-29 01:02:27'),
(5, 'change news', '2021-04-28 06:46:22', '2021-04-29 00:44:28'),
(7, 'second covid news', '2021-04-28 07:22:52', '2021-04-28 07:22:52'),
(9, 'second covid', '2021-04-28 07:25:07', '2021-04-28 07:25:07'),
(10, 'talath news', '2021-04-28 07:25:19', '2021-04-28 07:25:19'),
(11, 'talath news farzana', '2021-04-28 07:26:52', '2021-04-28 07:26:52'),
(12, 'second covid news', '2021-04-28 07:27:31', '2021-04-28 07:27:31'),
(13, 'first news', '2021-04-28 07:59:42', '2021-04-28 07:59:42'),
(14, 'second covid news', '2021-04-28 08:02:33', '2021-04-28 08:02:33'),
(15, 'news item', '2021-04-28 08:06:27', '2021-04-28 08:06:27'),
(16, 'third news', '2021-04-28 08:14:05', '2021-04-28 08:14:05'),
(17, 'first news', '2021-04-28 08:35:43', '2021-04-28 08:35:43'),
(18, 'validation check', '2021-04-28 08:36:32', '2021-04-28 08:36:32'),
(19, 'first news', '2021-04-28 08:38:31', '2021-04-28 08:38:31'),
(20, 'second covid', '2021-04-28 08:44:29', '2021-04-28 08:44:29'),
(21, 'talath news farzana', '2021-04-28 09:50:49', '2021-04-28 09:50:49'),
(22, 'News on Covid-19', '2021-04-28 11:05:06', '2021-04-28 11:05:06'),
(23, 'second covid', '2021-04-28 11:26:00', '2021-04-28 11:26:00'),
(24, 'updates on elections', '2021-04-28 22:08:48', '2021-04-28 22:08:48'),
(25, 'edit on different page and add on same page', '2021-04-28 23:48:35', '2021-04-29 00:37:12'),
(26, 'update check validation working redirect pending', '2021-04-29 00:30:42', '2021-04-29 00:35:04'),
(27, 'new check validation working', '2021-04-29 00:36:25', '2021-04-29 00:36:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_models`
--
ALTER TABLE `news_models`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news_models`
--
ALTER TABLE `news_models`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

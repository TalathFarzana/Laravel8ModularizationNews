<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>News | Edit</title>
</head>
<body>
<h1 style="text-align:center;">Edit News</h1>

    <form action="{{ url('news/update') }}" method="POST" name="news_edit_form" id="news_edit_form">
    @csrf
    @method('PATCH')
    <div class="form-group" style="text-align:center;">
    <input type="hidden" name="id" value="{{ $edit_news['id'] }}" readonly="readonly">
    <input type="text" name="title" value="{{ $edit_news['title'] }}" class="@error('title') is-invalid @enderror">
        @error('title')
              <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
        @enderror        
    <input type="submit" value="Update" name="update" class="btn btn-primary">
    </div>        
   </form>
   
   <div class="form-group" style="text-align:center;">
   <button class="btn btn-primary"><a href="/news"  style="text-align:center;text-decoration:none;color:#ffffff;">Back</a></button>
   </div> 
</body>
</html>
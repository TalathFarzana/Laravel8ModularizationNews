@extends('news::layouts.master')

@section('content')
   <!-- <h1>Hello World</h1>

    <p>
        This view is loaded from module: {!! config('news.name') !!}
    </p>-->

    <h1 style="text-align:center;"> Add News</h1>
    @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
    @endif
    @if(session('update_success'))
    <div class="alert alert-success">
        {{ session('update_success') }}
    </div>
    @endif
    @if(session('delete_success'))
    <div class="alert alert-success">
        {{ session('delete_success') }}
    </div>
    @endif
    <form action="{{ url('news/create') }}" method="post" name="news_form" id="news_form">
    @csrf
    <div class="form-group" style="text-align:center;">     
        <input type="text" name="title" class="@error('title') is-invalid @enderror">
        @error('title')
              <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
        @enderror
        <input type="submit" value="Add" name="add">
    </div>     
   </form>
   
   <div class="form-group" style="text-align:center;">
   <button class="btn btn-primary"><a href="/news"  style="text-align:center;text-decoration:none;color:#ffffff;">Back</a></button>
   </div> 

   <div class="form-group" style="margin-left:350px;margin-top:25px;">
   <h2>News Titiles List:</h2>
   @if(!empty($news_titles_list) && $news_titles_list->count())
   @foreach($news_titles_list as $news_list)
        {{ $news_list['id'] }}. {{ $news_list['title'] }}</br>
        <span style="margin-left:10px;"><a href="news/{{ $news_list['id'] }}"><input type="submit" class="btn btn-primary" value="Edit"></a></span>
        <span style="margin-left:25px;"><a href="/news/delete/{{ $news_list['id'] }}"><input type="submit" class="btn btn-danger" value="Delete"></a></span></br>
    @endforeach
    @else
    <span style="margin-left:25px;">There are no data.</span>
    @endif
    </div> 
    <div class="form-group" style="margin-left:350px;margin-top:25px;">
    {!! $news_titles_list->links() !!}
    </div>

@endsection

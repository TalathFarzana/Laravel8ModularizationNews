<?php

namespace Modules\News\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\News\Entities\NewsModel;

class NewsModel extends Model
{
    use HasFactory;
    protected $fillable=[
        'title'
    ];
}

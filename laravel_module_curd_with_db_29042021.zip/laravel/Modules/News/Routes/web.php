<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//using app/routes/news.php file
//Route::prefix('news')->group(function() {
    Route::get('/', 'NewsController@index');
    //Route::get('/', [NewsController::class, 'index']);
//});
//Route::prefix('news')->group(function() {
    Route::post('/create', 'NewsController@create');
//});
//Route::prefix('news')->group(function() {
    //Route::post('/add', 'NewsController@store');
//});
//Route::prefix('news')->group(function() {
    //Route::get('/edit', 'NewsController@edit');
//});


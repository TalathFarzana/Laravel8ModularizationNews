<?php

namespace Modules\News\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\News\Models\News;
use Modules\News\Entities\NewsModel;

class NewsController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $news_titles_list=NewsModel::paginate(5);
        return view('news::index', compact('news_titles_list'));
        /*$news_data=NewsModel::all();
        return view('news::index')->with('news_titles_list', $news_data);*/
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
    //
    return view('news::index');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'title' => 'required | max:255'
        ]);
        $newsm = new NewsModel;
        $newsm->title = $request->title;
        $newsm->save();
        return redirect()->back()->with('success', "News added successfully!");
        //return view('news::index');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('news::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $edit_news=NewsModel::find($id);
        return view('news::edit')->with('edit_news',$edit_news);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request)
    {
        //
        $request->validate([
            'title' => 'required | max:255'
        ]);
        $news_update = NewsModel::find($request->id);
        $news_update->title = $request->title;
        $news_update->save();
        return redirect('news')->with('update_success', "News updated successfully!");
        /*if($news_update->title <> $request->title){
        return redirect('news')->with('update_success', "News updated successfully!");
        }elseif($news_update->title == $request->title){
            //return "News not updated";
            return redirect('news')->with('update_success', "News updated with same data!");
        }*/
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
        $news_delete = NewsModel::find($id)->delete();
        if($news_delete){
        return redirect()->back()->with('delete_success', "Record $id News deleted successfully!");
        }else{
            return "Deletion failed!";
        }
    }
}
